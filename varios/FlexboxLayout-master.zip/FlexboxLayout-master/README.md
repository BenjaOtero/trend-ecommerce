FlexboxLayout
=============

Ejemplo de layout hecho con Flexbox en CSS3 para un tutorial escrito en Cristalab.

* Link al tutorial: http://www.cristalab.com/tutoriales/el-modulo-flexbox-de-css3-c112091l/
* Autor: Sergio Daniel Xalambrí
* Twitter: @sergiodxa
